<!DOCTYPE html>
<html>

<head>
	<style>
		body{
			background-image:url("poto1.jpg");
  background-position:center;
  background-attachment: fixed;
  background-size:cover;
		}
	</style>
	<title>Tambah</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
		integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
	<nav class="navbar navbar-expand-lg" style="background-color: #A7D397; color: #fff;">
		<div class="container-fluid">
			<a class="navbar-brand" href="pembayaran.php">pembayaran</a>
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
				aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarNav">
				<ul class="navbar-nav">

					<li class="nav-item">
					</li>
					<li class="nav-item">
					</li>
				</ul>
			</div>
		</div>
	</nav>
</head>

<body>

	<h2 style="color: white;" class="text-center mt-5">Tambah Data</h2>
	<br />
	<a href="pembayaran_admin.php">KEMBALI</a>
	<br />
	<br />
	<h2 style="color: white;">TAMBAH DATA PEMBAYARAN</h2>
	<form method="post" action="Tambahpembayaran_aksi.php">
		<table>
			<tr>
			<td style="color: white;">nik</td>

<td><select class="form-select" name="nik">
		<option selected>-PILIH- </option>
		<?php
		include 'koneksi.php';
		$no = 1;
		$data = mysqli_query($konn, "select * from siswa");
		while ($d = mysqli_fetch_array($data)) {
			?>
			<option value="<?php echo $d['nik']; ?>">
				<?php echo $d['nik']; ?>
			</option>
			<?php
		}
		?>

	</select></td>
			</tr>
			<tr>
				<td style="color: white;">nama</td>

				<td><select class="form-select" name="nama">
						<option selected>-PILIH- </option>
						<?php
						include 'koneksi.php';
						$no = 1;
						$data = mysqli_query($konn, "select * from siswa");
						while ($d = mysqli_fetch_array($data)) {
							?>
							<option value="<?php echo $d['nama']; ?>">
								<?php echo $d['nama']; ?>
							</option>
							<?php
						}
						?>

					</select></td>
			</tr>

			<tr>
				<td style="color: white;">tanggal</td>

				<td><input type="date" name="tanggal"></td>
			<tr>
				<td><input type="submit" value="SIMPAN"></td>
			</tr>
		</table>
	</form>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
		crossorigin="anonymous"></script>
</body>

</html>