<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data id yang di kirim dari url
$nik = $_GET['nik'];
 
 
// menghapus data dari database
mysqli_query($konn,"DELETE FROM siswa where nik='$nik'");
 
// mengalihkan halaman kembali ke index.php
header("location:siswa_admin.php");
 
?>
