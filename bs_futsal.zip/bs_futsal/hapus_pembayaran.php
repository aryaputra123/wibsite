<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data id yang di kirim dari url
$nik = $_GET['nik'];
 
 
// menghapus data dari database
mysqli_query($konn,"DELETE FROM pembayaran where nik='$nik'");
 
// mengalihkan halaman kembali ke index.php
header("location:pembayaran_admin.php");
 
?>
