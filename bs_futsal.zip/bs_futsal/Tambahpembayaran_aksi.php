<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data yang di kirim dari form
$nik = $_POST['nik'];
$nama = $_POST['nama'];
$tanggal = $_POST['tanggal'];

 
// menginput data ke database
mysqli_query($konn, "INSERT INTO pembayaran VALUES('$nik','$nama','$tanggal')");
 
// mengalihkan halaman kembali ke index.php
header("location:pembayaran_admin.php");
 
?>