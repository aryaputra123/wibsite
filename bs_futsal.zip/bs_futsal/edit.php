<!DOCTYPE html>
<html>
<head>
	<title>EDIT DATA PEMBAYARAN</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <nav class="navbar navbar-expand-lg" style = "background-color: #3876BF;; color: #fff;">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">siswa</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="pembayaran.php">pembayaran</a>
        </li>
        <li class="nav-item">
		<a class="nav-link active" aria-current="page" href="Tambah.php"></a>
        </li>
        <li class="nav-item">
		<a class="nav-link active" aria-current="page" href="Tambah_pembayaran.php"></a>
        </li>
        <li class="nav-item">
        </li>
      </ul>
    </div>
  </div>
</nav>
</head>
<body>
 
	<br/>
	<br/>
	<br/>
	<h3 class= "text-center mt-5">EDIT DATA PEMBAYARAN</h3>
 
	<?php
	include 'koneksi.php';
	$nik = $_GET['nik'];
	$data = mysqli_query($konn,"select * from pembayaran where nik='$nik'");
	while($d = mysqli_fetch_array($data)){
		?>
		<form method="post" action="editaksi.php">
			<table>
				<tr>			
					<td>nik </td>
					<td>
						<input type="text" name="nik" value="<?php echo $d['nik']; ?>">
						<input type="hidden" name="nik" value="<?php echo $d['nik']; ?>">
					</td>
				</tr>
				<tr>
					<td>nama</td>
					<td><input type="text" name="nama" value="<?php echo $d['nama']; ?>"></td>
				</tr>
                <tr>
					<td>tanggal</td>
					<td><input type="text" name="tanggal" value="<?php echo $d['tanggal']; ?>"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" value="SIMPAN"></td>
				</tr>		
			</table>
		</form>
		<?php 
	}
	?>
 
</body>
</html>