<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data yang di kirim dari form
$nik = $_POST['nik'];
$nama = $_POST['Nama'];
$kls = $_POST['kelas'];
$jrsn = $_POST['jurusan'];

 
// menginput data ke database
mysqli_query($konn, "INSERT INTO siswa VALUES('$nik','$nama','$kelas','$jurusan')");
 
// mengalihkan halaman kembali ke index.php
header("location:siswa_admin.php");
 
?>