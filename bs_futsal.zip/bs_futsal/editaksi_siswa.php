<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data yang di kirim dari form
$nik = $_POST['nik'];
$nama = $_POST['nama'];
$kelas = $_POST['kelas'];
$jurusan = $_POST['jurusan'];
 
// update data ke database
mysqli_query($konn,"UPDATE siswa SET nama='$nama', kelas='$kelas', jurusan='$jurusan' where nik='$nik'");
 
// mengalihkan halaman kembali ke index.php
header("location:siswa_admin.php");
 
?>